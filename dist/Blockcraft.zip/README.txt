BLOCKCRAFT
==========
A single-player block-building survival game. Every texture, sound and song is generated in code.
Just run Blockcraft.exe - nothing to install. Worlds are saved in the "saves" folder next to the .exe.
Needs a graphics card with OpenGL 3.3 (any PC from the last ~12 years).

CONTROLS
--------
W A S D ............ move
Mouse .............. look around
Space .............. jump (hold to swim up)
Left Shift ......... sneak (you won't walk off edges)
Left Ctrl .......... sprint (hold while moving forward)
Left mouse ......... mine a block (hold) / attack
Right mouse ........ place a block / use: eat food, draw the bow (release to shoot),
                     open crafting tables, furnaces and chests, open doors,
                     sleep in a bed (at night), till dirt with a hoe
1-9 / mouse wheel .. select hotbar slot
E .................. open / close inventory
Q .................. drop one item (Ctrl+Q drops the whole stack)
Esc ................ pause menu / close a screen
F1 ................. hide the HUD
F2 ................. screenshot (saved to the "screenshots" folder)
F3 ................. debug info (FPS, coordinates, biome, light)
F9 ................. export all generated textures to textures.png
F11 ................ fullscreen

INVENTORY SCREENS
-----------------
Left click ......... pick up / place / swap a stack
Right click ........ pick up half a stack / place one item
Shift + click ...... move a stack to the other side (or craft as many as possible)
Drag a held stack .. spread it evenly over slots (right-drag places one per slot)
1-9 over a slot .... swap with that hotbar slot
Click outside ...... drop the held stack

HIDDEN DEBUG KEYS
-----------------
F6 ................. debug fly mode (no gravity, no damage)
F7 (while flying) .. add a test kit of items
F8 (while flying) .. spawn one of every mob in front of you

GETTING STARTED
---------------
Punch a tree (hold left mouse) to get logs. Open the inventory (E) and turn logs into planks,
planks into sticks and a crafting table. Place the table, right-click it, and make a wooden pickaxe:
three planks across the top, two sticks down the middle. Dig stone for better tools, find coal
for torches, and build a shelter before your first night - Shamblers, Marrowshots, Fuselings and
Cragweavers come out in the dark. Kill sheep for wool and make a bed to skip the night.
